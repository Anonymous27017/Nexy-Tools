plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "ru.nexy.tools"
    compileSdk = 35

    defaultConfig {
        applicationId = "ru.nexy.tools"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"

        // ARM64-only build target. This does not convert old ARM32 native libraries.
        ndk { abiFilters += listOf("arm64-v8a") }
    }
}
