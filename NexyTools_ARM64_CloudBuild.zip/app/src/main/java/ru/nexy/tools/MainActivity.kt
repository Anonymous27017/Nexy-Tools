package ru.nexy.tools

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val serverAddress = "91.215.87.204:7777"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 48, 28, 28)
            setBackgroundColor(Color.rgb(15, 18, 30))
        }

        val title = TextView(this).apply {
            text = "NEXY TOOLS"
            textSize = 30f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        page.addView(title, matchWidthWrap())

        val edition = TextView(this).apply {
            text = "ARM64 EDITION"
            textSize = 14f
            setTextColor(Color.rgb(160, 174, 255))
            gravity = Gravity.CENTER
            setPadding(0, 8, 0, 36)
        }
        page.addView(edition, matchWidthWrap())

        val serverTitle = TextView(this).apply {
            text = "СЕРВЕР SWAG"
            textSize = 20f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        page.addView(serverTitle, matchWidthWrap())

        val address = TextView(this).apply {
            text = serverAddress
            textSize = 18f
            setTextColor(Color.rgb(210, 216, 235))
            gravity = Gravity.CENTER
            setPadding(0, 14, 0, 24)
        }
        page.addView(address, matchWidthWrap())

        val copyButton = Button(this).apply {
            text = "Скопировать адрес сервера"
            setOnClickListener {
                val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                clipboard.setPrimaryClip(ClipData.newPlainText("Nexy Tools server", serverAddress))
                Toast.makeText(this@MainActivity, "Адрес скопирован", Toast.LENGTH_SHORT).show()
            }
        }
        page.addView(copyButton, matchWidthWrap())

        val note = TextView(this).apply {
            text = "Это стартовая ARM64-версия интерфейса. Подключение к игре и перенос функций старого Nexy Tools ещё не реализованы."
            textSize = 14f
            setTextColor(Color.rgb(170, 178, 198))
            gravity = Gravity.CENTER
            setPadding(0, 36, 0, 0)
        }
        page.addView(note, matchWidthWrap())

        setContentView(page)
    }

    private fun matchWidthWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.WRAP_CONTENT
    )
}
